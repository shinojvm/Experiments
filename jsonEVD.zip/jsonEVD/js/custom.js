'use strict';

var options = {
    mode: 'tree',
    modes: ['code', 'tree'], // allowed modes
    onModeChange: function (newMode, oldMode) {
      console.log('Mode switched from', oldMode, 'to', newMode);
    }
  };
var editor = new JSONEditor( $('#jsoneditor')[0], options);

function loadJSON(lang, callback) {
	$.ajax({
		url: 'locales/' + lang + '/translation.json',
		type: 'GET',
		success: function(data) {
			var stringData = JSON.stringify(data);
			callback(stringData);
		},
		error: function(jqXHR) {
            console.warn('Some Error Occured');
        }
	})
}

function downLoadValidJSON(editedJSON) {

	var blob = new Blob([editedJSON], {
		type: "application/json"
	});

	var saveAs = window.saveAs;
	saveAs(blob, "editedJSON.json");
}

function validate(json) {
	try {
		var result = jsonlint.parse(json);
		if (result) {
			document.getElementById("result").innerHTML = "JSON is valid!";
			document.getElementById("result").className = "pass";
			return true;
		}
	} catch (e) {
		document.getElementById("result").innerHTML = e;
		document.getElementById("result").className = "fail";
		return false;
	}
}

function init() {
	$('select').val('0')

	$('select')
		.on('change', function() {
			var current = this.value;
			loadJSON(current, function(data) {
				editor.setText(data);
			})
		});

		$('button.save')
		.off('click')
		.on('click', function() {
			var editedJSON = editor.getText(); 
			if(validate(editedJSON)) {
				console.log("valid json");
			} else {
				console.log('invalid json');
			}
		});

		$('button.download')
		.off('click')
		.on('click', function() {
			var editedJSON = editor.getText();
			if(validate(editedJSON)) {
			 downLoadValidJSON(editedJSON);
			}
		});
}

window.onload = init;